#include "StdAfx.h"
#include "MemMapControl.h"

CMemMapControl::CMemMapControl(void)
: m_size(0)
{
}

CMemMapControl::~CMemMapControl(void)
{
}
